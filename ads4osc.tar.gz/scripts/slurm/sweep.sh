#!/bin/bash
#SBATCH --job-name=ads4osc_sweep
#SBATCH --output=sweep_%A_%a.out
#SBATCH --error=sweep_%A_%a.err
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=24
#SBATCH --mem=64G
#SBATCH --time=48:00:00
#SBATCH --partition=default
#SBATCH --array=0-14

# Parameter sweep: ell x Delta
# 5 ell values × 3 Delta values = 15 jobs
#
# Usage: sbatch sweep.sh
#
# Job array mapping:
#   index = i_ell * 3 + i_Delta
#   ell   ∈ {2, 4, 6, 8, 10}
#   Delta ∈ {4, 6, 10}

ELLS=(2 4 6 8 10)
DELTAS=(4 6 10)

N_DELTA=${#DELTAS[@]}
I_ELL=$(( SLURM_ARRAY_TASK_ID / N_DELTA ))
I_DELTA=$(( SLURM_ARRAY_TASK_ID % N_DELTA ))

ELL=${ELLS[$I_ELL]}
DELTA=${DELTAS[$I_DELTA]}

# Resolution — use production settings
# Higher ell may need more angular modes
if [ $ELL -le 4 ]; then
    N_NUC=10; N_SHELL=10; N_THETA=6
elif [ $ELL -le 8 ]; then
    N_NUC=10; N_SHELL=10; N_THETA=8
else
    N_NUC=12; N_SHELL=12; N_THETA=10
fi

W_MAX=0.5

export OMP_NUM_THREADS=${SLURM_CPUS_PER_TASK}
export OMP_PROC_BIND=close
export OMP_PLACES=cores

module purge 2>/dev/null || true
module load gcc/10.2.0 2>/dev/null || module load gcc 2>/dev/null || true
module load lapack 2>/dev/null || module load openblas 2>/dev/null || true

BASEDIR="$HOME/AdS4_Oscillons"
EXE="$BASEDIR/build_typhon/ads4osc_cli"
OUTDIR="$BASEDIR/results/sweep"

mkdir -p "$OUTDIR"
cd "$OUTDIR"

echo "=== Sweep job ${SLURM_ARRAY_TASK_ID}: ell=$ELL, Delta=$DELTA ==="
echo "Resolution: N_nuc=$N_NUC, N_shell=$N_SHELL, N_theta=$N_THETA"
echo "OMP_NUM_THREADS=$OMP_NUM_THREADS"
echo "Node: $(hostname)"
echo "Start: $(date)"
echo

$EXE --branch \
    --ell $ELL --Delta $DELTA \
    --N_nuc $N_NUC --N_shell $N_SHELL --N_theta $N_THETA \
    --w_max $W_MAX \
    --store --verbose \
    --output "branch_ell${ELL}_D${DELTA}_N${N_NUC}.csv"

echo
echo "End: $(date)"
