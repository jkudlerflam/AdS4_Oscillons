// oscillon_driver.cpp — Amplitude continuation driver
//
// The continuation loop parameterizes the solution branch by the normalization
// value w = phi_hat(tau=0, reference point). At leading order w ~ epsilon,
// so stepping in w is equivalent to stepping in amplitude.
//
// Adaptive stepping: the step dw is adjusted based on how many Newton
// iterations the previous solve took. Fast convergence → bigger steps;
// slow convergence → smaller steps.

#include "solver/oscillon_driver.h"
#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>

namespace solver {

OscillonDriver::OscillonDriver(const OscillonParams& params)
    : params_(params), sys_(params)
{}

// ============================================================================
// Solve at a single amplitude
// ============================================================================

bool OscillonDriver::solveAtEpsilon(
    double epsilon, NewtonResult& result,
    std::vector<double>& u_out, double& omega_out,
    const NewtonParams& np)
{
    int n = sys_.stateSize() - 1;
    u_out.resize(n);
    sys_.setLinearSeed(u_out.data(), omega_out, epsilon);

    double w_target = sys_.normalization(u_out.data());

    result = solveAtW(u_out.data(), omega_out, w_target, np);
    return result.converged;
}

// ============================================================================
// Solve at a given normalization target
// ============================================================================

NewtonResult OscillonDriver::solveAtW(
    double* u, double& omega, double w_target,
    const NewtonParams& np)
{
    int n = sys_.stateSize() - 1;

    // Wrap OscillonSystem methods into std::function for Newton
    auto residual_func = [this](const double* u_in, double om, double* R) {
        sys_.computeResidual(u_in, om, R);
    };

    auto norm_func = [this](const double* u_in) -> double {
        return sys_.normalization(u_in);
    };

    return newtonSolve(residual_func, norm_func,
                       u, omega, w_target, n, np);
}

// ============================================================================
// Continuation loop
// ============================================================================

std::vector<BranchPoint> OscillonDriver::runContinuation(
    const ContinuationParams& cont)
{
    std::vector<BranchPoint> branch;
    int n = sys_.stateSize() - 1;

    if (cont.verbose) {
        printf("========================================\n");
        printf("Oscillon continuation driver\n");
        printf("  ell = %d, Delta = %.1f, Lambda = %.1f\n",
               params_.ell, params_.Delta, params_.Lambda);
        printf("  N_t = %d, N_nuc = %d, N_shell = %d, N_theta = %d\n",
               params_.N_t, params_.N_nuc, params_.N_shell, params_.N_theta);
        printf("  eps_start = %.4e, dw_initial = %.4e, w_max = %.4e\n",
               cont.eps_start, cont.dw_initial, cont.w_max);
        printf("========================================\n\n");
    }

    // Step 1: Initialize with the linear seed at eps_start
    std::vector<double> u(n);
    double omega;
    sys_.setLinearSeed(u.data(), omega, cont.eps_start);
    double w_current = sys_.normalization(u.data());

    if (cont.verbose) {
        printf("Initial seed: eps = %.4e, w = %.6e, omega = %.10f\n",
               cont.eps_start, w_current, omega);
    }

    // Step 2: First Newton solve at the seed amplitude
    NewtonResult result = solveAtW(u.data(), omega, w_current, cont.newton);

    if (!result.converged) {
        if (cont.verbose)
            printf("FAILED: Newton did not converge at initial amplitude.\n");
        return branch;
    }

    // Record first branch point
    {
        BranchPoint bp;
        bp.w = w_current;
        bp.omega = omega;
        bp.residual = result.final_residual;
        bp.newton_iters = result.iterations;
        if (cont.store_solutions) bp.u = std::vector<double>(u.begin(), u.end());
        branch.push_back(bp);

        if (cont.verbose) {
            printf("\nBranch point %d: w = %.6e, omega = %.10f, "
                   "res = %.2e, iters = %d\n",
                   (int)branch.size(), bp.w, bp.omega,
                   bp.residual, bp.newton_iters);
        }
    }

    // Step 3: Continuation loop — step up w
    double dw = cont.dw_initial;
    std::vector<double> u_prev(n); // backup for retry

    while (w_current < cont.w_max &&
           (int)branch.size() < cont.max_branch_points)
    {
        // Save current solution as backup
        std::copy(u.begin(), u.end(), u_prev.begin());
        double omega_prev = omega;
        double w_prev = w_current;

        // Step w
        double w_next = w_current + dw;

        if (cont.verbose) {
            printf("\n--- Attempting w = %.6e (dw = %.4e) ---\n", w_next, dw);
        }

        // Try Newton solve at new w
        result = solveAtW(u.data(), omega, w_next, cont.newton);

        if (result.converged) {
            w_current = w_next;

            BranchPoint bp;
            bp.w = w_current;
            bp.omega = omega;
            bp.residual = result.final_residual;
            bp.newton_iters = result.iterations;
            if (cont.store_solutions)
                bp.u = std::vector<double>(u.begin(), u.end());
            branch.push_back(bp);

            if (cont.verbose) {
                printf("Branch point %d: w = %.6e, omega = %.10f, "
                       "res = %.2e, iters = %d\n",
                       (int)branch.size(), bp.w, bp.omega,
                       bp.residual, bp.newton_iters);
            }

            // Adaptive step adjustment
            if (result.iterations <= cont.fast_iters) {
                dw = std::min(dw * cont.step_increase, cont.dw_max);
            } else if (result.iterations >= cont.slow_iters) {
                dw = std::max(dw * cont.step_decrease, cont.dw_min);
            }

        } else {
            // Newton failed — restore previous solution, reduce step
            if (cont.verbose)
                printf("Newton failed at w = %.6e, reducing step\n", w_next);

            std::copy(u_prev.begin(), u_prev.end(), u.begin());
            omega = omega_prev;
            w_current = w_prev;

            dw *= cont.step_decrease;

            if (dw < cont.dw_min) {
                if (cont.verbose)
                    printf("Step size below minimum (%.2e < %.2e), stopping.\n",
                           dw, cont.dw_min);
                break;
            }
        }
    }

    if (cont.verbose) {
        printf("\n========================================\n");
        printf("Continuation complete: %d branch points\n", (int)branch.size());
        if (!branch.empty()) {
            printf("  w range: [%.6e, %.6e]\n", branch.front().w, branch.back().w);
            printf("  omega range: [%.10f, %.10f]\n",
                   branch.back().omega, branch.front().omega);
        }
        printf("========================================\n");
    }

    return branch;
}

} // namespace solver
