// oscillon_driver.h — Amplitude continuation driver for the oscillon system
//
// Strategy:
//   1. Initialize at small epsilon using the linear eigenmode seed
//   2. Newton-solve to get the first nonlinear solution
//   3. Step up the normalization target w, using the previous solution as seed
//   4. Continue until Newton fails to converge or w exceeds w_max
//
// The normalization w = phi_hat(tau=0, reference point) is proportional to
// epsilon at leading order. Stepping in w gives a natural parameterization
// of the solution branch.
#pragma once

#include "solver/oscillon_system.h"
#include "solver/newton.h"
#include <vector>
#include <string>

namespace solver {

// A single point on the solution branch
struct BranchPoint {
    double w;             // normalization value
    double omega;         // frequency
    double residual;      // final Newton residual
    int newton_iters;     // Newton iterations used
    std::vector<double> u; // full state vector (optional, can be empty to save memory)
};

// Parameters for the continuation driver
struct ContinuationParams {
    // Starting amplitude
    double eps_start = 0.01;

    // Normalization stepping
    double dw_initial = 0.005;   // initial step in w
    double dw_min = 1e-6;        // minimum step
    double dw_max = 0.1;         // maximum step
    double w_max = 10.0;         // stop when w exceeds this

    // Adaptive stepping
    int fast_iters = 5;          // if Newton converges in <= this, increase step
    int slow_iters = 15;         // if Newton takes >= this, decrease step
    double step_increase = 1.5;  // factor to increase dw
    double step_decrease = 0.5;  // factor to decrease dw

    // Newton parameters
    NewtonParams newton;

    // Storage options
    bool store_solutions = false; // if true, store full u at each branch point
    int max_branch_points = 1000; // safety limit

    // Output
    bool verbose = true;
};

class OscillonDriver {
public:
    OscillonDriver(const OscillonParams& params);

    // Run the continuation from eps_start up to w_max or until convergence fails.
    // Returns the solution branch.
    std::vector<BranchPoint> runContinuation(const ContinuationParams& cont = ContinuationParams());

    // Solve at a single amplitude epsilon.
    // Returns true if Newton converged.
    bool solveAtEpsilon(double epsilon, NewtonResult& result,
                        std::vector<double>& u_out, double& omega_out,
                        const NewtonParams& np = NewtonParams());

    // Solve at a given normalization target w, starting from initial guess u, omega.
    // u and omega are modified in place.
    NewtonResult solveAtW(double* u, double& omega, double w_target,
                          const NewtonParams& np = NewtonParams());

    // Access the underlying system
    const OscillonSystem& system() const { return sys_; }

private:
    OscillonParams params_;
    OscillonSystem sys_;
};

} // namespace solver
